#ifndef __BURSTADCSAMPLER_h__
#define __BURSTADCSAMPLER_h__

#include "Pinouts.h"
#include <Arduino.h>
#include <SD.h>
#include <SPI.h>
#include <stdio.h>

struct node {
  int data;
  struct node *next;
} typedef node;

class BurstADCSampler {
private:
  node *headarray[10] = {NULL};

  // helper func
  void update(void);
  void timestamp(void);
  void save(void);
  void cleanup(void);
  void namefile(void);

  // String basename = "datalog_salinity_";
  String basename = "";
  String filename = "";
  const int TIME_INDEX = 0;

  const int num_burst_pins;
  int num_samples;
  int *const pinMap;

public:
  BurstADCSampler(const int pins[], const int num_burst_pins,
                  const int num_samples, const String name);

  void sample(void);
  void print(void);
  void init(void);

  int lastExecutionTime = -1;
};

#endif
