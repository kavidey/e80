#include "BurstADCSampler.h"
#include <SD.h>
#include <SPI.h>
#include <stdio.h>

BurstADCSampler::BurstADCSampler(const int *pins, const int num_burst_pins,
                                 const int num_samples, const String name)
    : pinMap(new int[num_burst_pins]), num_burst_pins(num_burst_pins),
      basename(name + "_"), num_samples(num_samples) {
  for (int i = 0; i < num_burst_pins; ++i) {
    pinMap[i] = pins[i];
  }
};

void BurstADCSampler::init() {
  Serial.print("Initializing SD Card... ");
  if (!SD.begin()) {
    Serial.println("failed!");
    return;
  }
  Serial.print("done!");
  namefile();
}

// create lists for each pin and rapidly collect data from each pin
// and save data into seperate file
void BurstADCSampler::sample() {
  for (int i = 0; i < num_samples; i++) {
    update();
  }
  save();
  cleanup();
}

// delete all dynamically allocated memory
void BurstADCSampler::cleanup() {
  for (int i = 0; i < num_burst_pins + 1; i++) {
    node *curr = headarray[i];
    while (curr != nullptr) {
      node *next = curr->next;
      delete curr;
      curr = next;
    }
  }
  for (int i = 0; i < num_burst_pins + 1; i++) {
    headarray[i] = NULL;
  }
}

// for each pin
// create new node, read data from pin, add to the list
void BurstADCSampler::update() {
  timestamp();
  for (int i = 0; i < num_burst_pins; i++) {
    node *curr = new node;
    curr->data = analogRead(pinMap[i]);
    curr->next = headarray[i + 1];
    headarray[i + 1] = curr;
  }
}

// update the TIME_INDEX list with current time
void BurstADCSampler::timestamp() {
  node *time_node = new node;
  time_node->data = micros();
  time_node->next = headarray[TIME_INDEX];
  headarray[TIME_INDEX] = time_node;
}

// save data onto SD card
void BurstADCSampler::save() {
  File dataFile = SD.open(filename.c_str(), FILE_WRITE);
  if (dataFile) {
    for (int i = 0; i < num_burst_pins + 1; i++) {
      node *curr = headarray[i];
      while (curr != nullptr) {
        dataFile.print(curr->data);
        dataFile.print(",");
        curr = curr->next;
      }
      dataFile.print("\n");
    }
    dataFile.close();
  }
}

// name the burst file
// only done once per run
// all subsequent calls to update() will
// append to file, NOT create a new file during same run
void BurstADCSampler::namefile() {
  filename = basename;
  int i = 0;
  while (SD.exists(filename.c_str())) {
    i++;
    filename = basename + i;
  }
}

// for debugging
// dump each list into serial
void BurstADCSampler::print() {
  for (int i = 0; i < num_burst_pins + 1; i++) {
    node *curr = headarray[i];
    while (curr != nullptr) {
      Serial.print(curr->data);
      Serial.print(",");
      curr = curr->next;
    }
    Serial.print("\n");
  }
}
